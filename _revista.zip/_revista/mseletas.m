function rede = mseletas(W)
[~, raio, ~, ~, ma, ~, ~, ~, ~, ~, MStot, r0] = MedidasDeRedes(W);
rede = [raio; ma; MStot; r0; mean(weighted_clust_coeff(W))];
end