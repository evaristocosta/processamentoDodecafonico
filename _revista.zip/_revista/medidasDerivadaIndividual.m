function dados = medidasDerivadaIndividual(serie)

%Vetor de intervalos
intr = diff(serie);
s1I = intr;
%Vetor de intervalos normais
s1IN = abs(s1I);


%Intervalos dissonantes
intrv_diss = intervalosdisonantes(intr);

%Estabilidade de contorno
[EC,ECP,ECN] = estabilidaddelcontorno(serie);

%Movimentos por passo
Mpp = movimientosporpaso(intr);

% -----------------------------------
%Maior e menor intervalo geral
[M, m] = intervalomayormenor(s1I);

%Diferença entre maior e menor intervalo gerais
diff_interv = M - m;

%Médias 
m_artm = mean(s1I);
m_artmN = mean(s1IN);
%Desvios padrão
dsv_p = std(s1I);
dsv_pN = std(s1IN);

%Média ponderada normal
s1IR = interv2razao(s1IN);
m_pond = sum(s1I.*s1IR)/sum(s1IR);
%Desvio padrão ponderado normal
dsv_p_pond = sqrt(var(s1I,s1IR));

%Modas, frequência e modas repetidas
[moda, frq, othr] = mode(s1I);
othr_rp = cell2mat(othr);
othr_rep = length(othr_rp);

%Assimetria
assimetria = (m_artm - moda)/dsv_p;

%               1           2   3    4    5   6  7      8          9     10 	 11      12          13   14       15     
dados(1:15) = {intrv_diss, EC, ECP, ECN, Mpp, M, m, diff_interv, m_artm, dsv_p, m_pond, dsv_p_pond, moda, frq, assimetria};
end