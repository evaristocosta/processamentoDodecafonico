%M = [0 2 3 0;0 0 0 3;0 1 0 3;0 0 4 0];

%function [lambda IW DM EG MH V ecc radius CsG N3 N4 N5] = todasMedidasDigrafos2(M)
function [lambda IW DM] = todasMedidasDigrafos2(M)


N = length(M);
D = inf2zero(floydwarshall(M,N));
A = double(M>0); %..Matriz de adjacencia bin�ria (digrafo sem pesos )

% Mean of finite entries of D(G)
lambda = sum(sum(D(D~=Inf)))/length(nonzeros(D~=Inf));
%..Indice de wiener
IW = sum(sum(D));
%..Distancia media
DM = (1/(N*(N-1)))*IW;
%..Efici�ncia global
% EG = fEficienciaGlobal(D);
% %..M�dia harm�nica
% MH = 1/EG;
% %..Vulnerabilidade
% [V,Vi,EGi] = fVulnerabilidade(M);
% 
% %..Indices de centralidade......
% %...a. Excentrecidade (para cada n�, ignora Inf)
% ecc = max(D.*(D~=Inf),[],2);
% radius = min(ecc);  % Radius of graph % but what about zeros?
% %...b. proximidade
% %...c. valor centroide
% %...............................
% 
% %..Centralidade de sub-grafo...
% Av = eig(full(M)); %..autovalores de M
% CsG = sum(cosh(Av))/sum(exp(Av));
% %..............................
% 
% %..Estruturas ciclicas
% N3 = (1/6)*sum(diag(A^3));
% a = sum(diag(A^4));
% b = 2*sum(diag(A^2).*diag(A^2));
% c = sum(diag(A^2));
% N4 = (1/8)*(a-b+c);
% a = sum(diag(A^5));
% b = 5*sum(diag(A^2).*diag(A^3));
% c = sum(diag(A^3));
% N5 = (1/10)*(a-b+c);
% 
% %medidas2 = [lambda IW DM EG MH V ecc radius CsG N3 N4 N5];