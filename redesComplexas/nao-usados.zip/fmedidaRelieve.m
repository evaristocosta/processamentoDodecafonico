clear all

%M = [10000 10; 10 10];
M = zeros(10);
M(10:10,:) = 1;

%function mr = fmedidaRelieve(M)

A = single(M>0);
n = length(M);

%..para M. Adj. bin�rias
num1 = 0;
% num2 = 0;
for i=1:n
    for j=1:n
        num1 = num1 + i*j*A(i,j);
%         num2 = num2 + i*j*M(i,j);
    end
end
%.............................

%..para rede com pessos....
% M2 = M;
% for i=1:n
%     for j=1:n
%         if M(i,j)==0
%           M2(i,j) = 1;
%         end
%     end
% end
%.............................

% num3 = 0;
% for i=1:n
%     for j=1:n
%         num3 = num3 + i*j*M2(i,j);
%     end
% end
%..........................

den = (n*(n+1))^2;
mr = 4 * num1 / den


%.........................