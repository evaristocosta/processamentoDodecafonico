
%...vector de notas....
P = [1 2 2 3 4 5 6 7 8 9 10 12 11 12 12 12 16 11 1 10 10 9 7 6 6 5 6 7 7 7 8 9]; P = P-1; %..da bem com algo. e com matriz
%P=[2 2 2 2 2 2 2 2 3 3 6]; %..com algo da 0.1 com matriz 0.2
%P=[2 2 2 2 2 2 2 2 3 3 6 3 3 2 2 2 2 2 2 2 2];   %..com algo da 0.1 com matriz 0.2
%P = fcrearmatrizadj(p);

%......................Variedade do pitch..................................
%..Obtener la longitud, el m�xim, el m�nimo.+
  n = length(P);
inf = min(P);
sup = max(P);
V = histc(P,inf:sup);
lv = length(V);
V1 = [];
 k = 1;
for i=1:lv
    if V(1,i)>0
        V1(1,k)=V(1,i);
        k=k+1;
    end
end
ndif=length(V1);
VT=ndif/n;
%P = mod(pitch(P)',12);
[Mp,Np] = fcrearmatrizadj(P);
Kout = sum(Mp,2);   %..grau de sa�da
Kin = sum(Mp',2);  %..grau de entrada
Ktot = Kout + Kin;  %..grau total local (in + out)
Npu = sum(sum(triu(Mp+Mp',1)));
Nt = sum(Ktot)/2; %..total de arestas
Vp = (Npu + 1) /(Nt + 1);
%..........................................................................

%........direccion de contorno asc., desc. e const.........................
n = length(P);
for i=1:n-1
    I(i)=P(i+1)-P(i);
end
%...contar los intervalos ascendentes y descendentes
Ia = 0; %..intervalos ascendentes
Ii = 0; %..intervalos iguales
Id = 0; %..intervalos descendentes
for i=1:n-1
    if I(1,i)>0
        Ia=Ia+1; 
    else
       if I(1,i)==0
         Ii=Ii+1;    
       else
         Id=Id+1;   
       end
    end
end
Ia, Ii, Id
dca = Ia/(n-1) %..densidad de intervalos ascendentes
dci = Ii/(n-1) %..densidad de intervalos iguales
dcd = Id/(n-1) %..densidad de intervalos descendentes

Da = sum(sum(triu(Mp,1))) / Nt;
Db = sum(sum(tril(Mp,-1))) / Nt;
Dc = sum(diag(Mp)) / Nt;
%..........................................................................

%..........................Intervalos disonantes...........................
%P = [1 2 0 11 6 1 3 4 0 10 11 1];
n = length(P);
I = zeros(1,n-1);
for i=1:n-1 %..se halla el valor absoluto de I porque no importa la direcci�n del intervalos
    I(i)= abs(P(i+1)-P(i));
end 
n = length(I);
id=0;
for i=1:n
   if (I(i)==1)||(I(i)==6)||(I(i)==10)||(I(i)==11)
      id=id+1;
   end
end
pid=id/n;

[Mp,nosp] = fcrearmatrizadj(mod(P,12));
nosNotas = 0:11;
Mp = fcodeRitmo2MAdj(Mp,nosNotas,nosp,2);
M = triu(Mp+abs(Mp-Mp'));
 Id1 = sum(diag(M,1));
 Id6 = sum(diag(M,6));
Id10 = sum(diag(M,10));
Id11 = sum(diag(M,11));
  Id = (Id1+Id6+Id10+Id11)/ (Nt); %..div. 2, porque 2 3 2 se conta duas vezes na Mp
%..........................................................................

%........................movimentos por passo..............................
%P=[2 4 4 5 7 8 7 9 9 9 12 0 9 9 9 8 7 6 4 3];
%P=[2 3 2 3 2 3 2 3 4 3 1 2 3 4 3 2 1];
I = abs(intervalos(P));
n = length(I);
idiat = 0; 
for i=1:n
    if (abs(I(1,i))==1) || (abs(I(1,i))==2)
        idiat = idiat+1;
    end
end
Mpp=idiat/n;

I1s = sum(diag(Mp,1));
I1i = sum(diag(Mp,2));
 MP = (I1s+I1i)/Nt;
%..........................................................................

%.....
P=[1 5 3 4 5 4 1 2 5 4 5 3 4];
R=[2 1 4 5 6 7 1 5 1 9 8 7 1];
%..n�mero de figuras r�tmicas
nr = length(R);
 N = length(P);
q = min(R);
nq = 0;     
for i=1:nr

    if R(1,i)==q
        nq=nq+1;
    end
end
tonalidad = 1; 
b=0; j=0;
while (b==0)
    for i=1:N
        if P(i)== (tonalidad + (12*j));
            tonica = P(i);
            b=1;
        end
    end
    j=j+1;
end
dominante = tonica + 7;
        P = mod(P,12);
   tonica = mod(tonica,12);
dominante = mod(dominante,12);
nqq=0;
for i=1:N
  if ((R(i)==q) && (P(i)==tonica))  || ((R(i)==q) && (P(i)==dominante))
      nqq = nqq + 1;
  end
end
Tc=nqq/nq;
%..n�mero de veces que la tonica o la dominante se ejecutan con la figura de menor duraci�n / cantidad de figuras con menor duraci�n 


%..Estabilidade do contorno melodico...............
 P=[0 2 0 0 4 5 7 2 0 7 4 2 5 7 0];
 n = length(P);
I = zeros(1,n-1);
for i=1:n-1 %..se halla el valor absoluto de I porque no importa la direcci�n del intervalos
    I(i)= P(i+1)-P(i);
end 
sI = sign(I);
sII = fcrearmatrizadj(sI);
tEc = diag(sII);

[II,nII] = fcrearmatrizadj(I)
Vintervalos = -11:11;
MI = fcodeRitmo2MAdj(II,Vintervalos,nII,2);
sII2(1,1) = sum(sum(MI(1:11,1:11)));
sII2(1,2) = sum(sum(MI(1:11,12))); 
sII2(1,3) = sum(sum(MI(1:11,13:23)));
sII2(2,1) = sum(sum(MI(12,1:11)));
sII2(2,2) = sum(sum(MI(12,12)));
sII2(2,3) = sum(sum(MI(12,13:23)));
sII2(3,1) = sum(sum(MI(13:23,1:11)));
sII2(3,2) = sum(sum(MI(13:23,12)));
sII2(3,3) = sum(sum(MI(13:23,13:23)));
tI = sum(sum(II)) + 1;
sII2(1,1) / tI
sII2(2,2) / tI
sII2(3,3) / tI
%.........................................................



