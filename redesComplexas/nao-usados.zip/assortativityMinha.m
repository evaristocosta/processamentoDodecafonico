



[id,od,deg] = degrees_dir(CIJ);
[i,j] = find(CIJ>0);
K = length(i);
for k=1:K
    degi(k) = deg(i(k));
    degj(k) = deg(j(k));
end;


% compute assortativity
a = sum(degi.*degj)/K;
b = (sum(0.5*(degi+degj))/K)^2;
c = sum(0.5*(degi.^2+degj.^2))/K;
r = ( a - b )/( c - b);

%..densidade
N = size(CIJ,1); %..n�mero de n�s
K = nnz(CIJ);    %..n�mero de elementos n�o zero 
kden = K/(N^2-N);

density_dir(~eye(4)) %..todos conectados com todos = 1