%..Efici�ncia global

function EG = fEficienciaGlobal(D)

n = length(D);

% Efficiency: mean of inverse entries of D(G)
D = 1./D;                           %invert distance
D(1:n+1:end) = 0;                   %set diagonal to 0
EG = sum(D(:))/(n*(n-1));   %compute global efficiency


