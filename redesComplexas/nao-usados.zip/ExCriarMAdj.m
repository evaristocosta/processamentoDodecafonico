% 
% v = [1 2 2 3 3 2 1 2 1]; 
% 
% [M,Vu]= fcrearmatrizadj2(v);
% 
% v2 = [1 -7 9 -7 2 6 1 -6 1 -6 3];
% %     -7 -6 1 2 3 6 9 -> 1 2 3 4 5 6 7
% v3 = [3 1 7 1 4 6 3 2 3 2 5];
% 
% [M2,Vu2]= fcrearmatrizadj2(v3);



Meds = fMedidasRedesClassificacao(M2);
