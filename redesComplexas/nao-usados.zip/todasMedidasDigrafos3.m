
 M = [0 2 3 0;0 0 0 3;0 1 0 3;0 0 4 0];
 A = double(M>0);


%   The rich club coefficient, R, at level k is the fraction of edges that
%   connect nodes of degree k or higher out of the maximum number of edges
%   that such nodes might share.
[R,Nk,Ek] = rich_club_bd(A)

%   The s-core is the largest subnetwork comprising nodes of strength at
%   least s. This function computes the s-core for a given weighted
%   undirected connection matrix. Computation is analogous to the more
%   widely used k-core, but is based on node strengths instead of node
%   degrees. 
[CIJscore,sn] = score_wu(A,0.5)

%   The subgraph centrality of a node is a weighted sum of closed walks of
%   different lengths in the network starting and ending at the node. This
%   function returns a vector of subgraph centralities for each node of the
%   network.
Cs = subgraph_centrality(A)

%   The global efficiency is the average of inverse shortest path length, 
%   and is inversely related to the characteristic path length.
E1=efficiency_bin(A)
E2=efficiency_bin(A,1)

%   Eigenector centrality is a self-referential measure of centrality:
%   nodes have high eigenvector centrality if they connect to other nodes
%   that have high eigenvector centrality. The eigenvector centrality of
%   node i is equivalent to the ith element in the eigenvector 
%   corresponding to the largest eigenvalue of the adjacency matrix.
v = eigenvector_centrality_und(A)

%   Computes the flow coefficient for each node and averaged over the
%   network, as described in Honey et al. (2007) PNAS. The flow coefficient
%   is similar to betweenness centrality, but works on a local
%   neighborhood. It is mathematically related to the clustering
%   coefficient  (cc) at each node as, fc+cc <= 1.
[fc,FC,total_flo] = flow_coef_bd(A)

%   Returns the components of an undirected graph specified by the binary and 
%   undirected adjacency matrix adj. Components and their constitutent nodes are 
%   assigned the same index and stored in the vector, comps. The vector, comp_sizes,
%   contains the number of nodes beloning to each component.
[comps,comp_sizes] = get_components(A)

%   The m-th step generalized topological overlap measure (GTOM) quantifies
%   the extent to which a pair of nodes have similar m-th step neighbors.
%   Mth-step neighbors are nodes that are reachable by a path of at most
%   length m.
gt = gtom(A,3)

%   The k-core is the largest subnetwork comprising nodes of degree at
%   least k. This function computes the k-core for a given binary directed
%   connection matrix by recursively peeling off nodes with degree lower
%   than k, until no such nodes remain.
[CIJkcore,kn,peelorder,peellevel] = kcore_bd(A,3)

%   The k-core is the largest subgraph comprising nodes of degree at least
%   k. The coreness of a node is k if the node belongs to the k-core but
%   not to the (k+1)-core. This function computes k-coreness of all nodes
%   for a given binary directed connection matrix.
[coreness,kn] = kcoreness_centrality_bd(A)

%   The PageRank centrality is a variant of eigenvector centrality. This
%   function computes the PageRank centrality of each vertex in a graph.
%
%   Formally, PageRank is defined as the stationary distribution achieved
%   by instantiating a Markov chain on a graph. The PageRank centrality of
%   a given vertex, then, is proportional to the number of steps (or amount
%   of time) spent at that vertex as a result of such a process. 
%
%   The PageRank index gets modified by the addition of a damping factor,
%   d. In terms of a Markov chain, the damping factor specifies the
%   fraction of the time that a random walker will transition to one of its
%   current state's neighbors. The remaining fraction of the time the
%   walker is restarted at a random vertex. A common value for the damping
%   factor is d = 0.85.
 r = pagerank_centrality(A,0.85,0.1)
 
%   The assortativity coefficient is a correlation coefficient between the
%   degrees of all nodes on two opposite ends of a link. A positive
%   assortativity coefficient indicates that nodes tend to link to other
%   nodes with the same or similar degree.
%   Inputs:     CIJ,    binary directed/undirected connection matrix
%               flag,   0, undirected graph: degree/degree correlation
%                       1, directed graph: out-degree/in-degree correlation
%                       2, directed graph: in-degree/out-degree correlation
%                       3, directed graph: out-degree/out-degree correlation
%                       4, directed graph: in-degree/in-degree correlation
CAss1 = assortativity_bin(A,1)
CAss2 = assortativity_bin(A,2)
CAss3 = assortativity_bin(A,3)
CAss4 = assortativity_bin(A,4)

%...Motivos
%   Functional motifs are subsets of connection patterns embedded within 
%   anatomical motifs. Motif frequency is the frequency of occurrence of 
%   motifs around a node.
[f F]=motif4funct_bin(A);
[f F]=motif3funct_bin(A)

%   Functional motifs are subsets of connection patterns embedded within 
%   anatomical motifs. Motif frequency is the frequency of occurrence of 
%   motifs around a node. Motif intensity and coherence are weighted 
%   generalizations of motif frequency. 
[I Q F] = motif3funct_wei(M);
%   Structural motifs are patterns of local connectivity. Motif frequency
%   is the frequency of occurrence of motifs around a node. Motif intensity
%   and coherence are weighted generalizations of motif frequency.
[I Q F] = motif3struct_wei(W);
%   Functional motifs are subsets of connection patterns embedded within 
%   anatomical motifs. Motif frequency is the frequency of occurrence of 
%   motifs around a node. Motif intensity and coherence are weighted 
%   generalizations of motif frequency. 
[I Q F] = motif4funct_wei(W);
%   Structural motifs are patterns of local connectivity. Motif frequency
%   is the frequency of occurrence of motifs around a node. Motif intensity
%   and coherence are weighted generalizations of motif frequency. 
[I Q F] = motif4struct_wei(W);

%   This function returns all motif isomorphs for a given motif id and 
%   class (3 or 4). The function also returns the motif id for a given
%   motif matrix
fm34=find_motif34([0 1 0; 0 0 1; 1 0 0])
%   Walks are sequences of linked nodes, that may visit a single node more
%   than once. This function finds the number of walks of a given length, 
%   between any two nodes.
[Wq,twalk,wlq] = findwalks(M)
%   make_motif34lib;
%   This function generates the motif34lib.mat library required for all
%   other motif computations.

%   The within-module degree z-score is a within-module version of degree
%   centrality.
 Ci = [1 2 2 1]; %..community affiliation vector
Z=module_degree_zscore(M,Ci)

%   This function determines the neighbors of two nodes that are linked by 
%   an edge, and then computes their overlap.  Connection matrix must be
%   binary and directed.  Entries of 'EC' that are 'inf' indicate that no
%   edge is present.  Entries of 'EC' that are 0 denote "local bridges",
%   i.e. edges that link completely non-overlapping neighborhoods.  Low
%   values of EC indicate edges that are "weak ties".
[EC,ec,degij] = edge_nei_overlap_bd(M)

%   Edge betweenness centrality is the fraction of all shortest paths in 
%   the network that contain a given edge. Edges with high values of 
%   betweenness centrality participate in a large number of shortest paths.
[EBC BC]=edge_betweenness_wei(M)

%   Node betweenness centrality is the fraction of all shortest paths in 
%   the network that contain a given node. Nodes with high values of 
%   betweenness centrality participate in a large number of shortest paths.
BC=betweenness_wei(M)

%   The global efficiency is the average of inverse shortest path length, 
%   and is inversely related to the characteristic path length.
  Eglob = efficiency_wei(M);
  Eloc = efficiency_wei(M,1);
 
  %   The distance matrix contains lengths of shortest paths between all
  %   pairs of nodes. An entry (u,v) represents the length of shortest path
  %   from node u to node v. The average shortest path length is the
  %   characteristic path length of the network.
  [D B]=distance_wei(M)
  
  %   This function "thresholds" the connectivity matrix by preserving a
  %   proportion p (0<p<1) of the strongest weights. All other weights, and
  %   all weights on the main diagonal (self-self connections) are set to 0.
  TP1 = threshold_proportional(M,0)
  TP2 = threshold_proportional(M,1)
  
  %   The Shannon-entropy based diversity coefficient measures the diversity
  %   of intermodular connections of individual nodes and ranges from 0 to 1.
  [Hpos Hneg] = diversity_coef_sign(M, Ci)
  
  %   Participation coefficient is a measure of diversity of intermodular
  %   connections of individual nodes.
  [Ppos Pneg]=participation_coef_sign(M,Ci)
  P=participation_coef(M,Ci)
  
  %   Density is the fraction of present connections to possible connections.
  [kden,N,K] = density_dir(M)
  
  %   Shorcuts are central edges which significantly reduce the
  %   characteristic path length in the network.
  [Erange,eta,Eshort,fs] = erange(M)
  
  %   This function returns a matrix in which the value of each element (u,v)
%   corresponds to the number of nodes that have u outgoing connections 
%   and v incoming connections.
  [J,J_od,J_id,J_bl] = jdegree(M)
  
%   For any two nodes u and v, the matching index computes the amount of
%   overlap in the connection patterns of u and v. Self-connections and
%   u-v connections are ignored. The matching index is a symmetric 
%   quantity, similar to a correlation or a dot product.  
[Min,Mout,Mall] = matching_ind(M);

%   The binary reachability matrix describes reachability between all pairs
%   of nodes. An entry (u,v)=1 means that there exists a path from node u
%   to node v; alternatively (u,v)=0.
[R,D] = reachdist(M)

%   Node strength is the sum of weights of links connected to the node. The
%   instrength is the sum of inward link weights and the outstrength is the
%   sum of outward link weights.
[is,os,str] = strengths_dir(M);


%   This function thresholds the connectivity matrix by absolute weight
%   magnitude. All weights below the given threshold, and all weights
%   on the main diagonal (self-self connections) are set to 0.
W_thr = threshold_absolute(M, 0.1)


%   Transitivity is the ratio of 'triangles to triplets' in the network.
%   (A classical version of the clustering coefficient).
T = transitivity_wd(M);
T = transitivity_bd(M);

%   The optimal community structure is a subdivision of the network into
%   nonoverlapping groups of nodes in a way that maximizes the number of
%   within-group edges, and minimizes the number of between-group edges. 
%   The modularity is a statistic that quantifies the degree to which the
%   network may be subdivided into such clearly delineated groups. 
[Ci Q] = modularity_dir(M);


  %..Gerar redes
%MAKEEVENCIJ        Synthetic modular small-world network
%   CIJ = makeevenCIJ(N,K,sz_cl);
%   This function generates a random, directed network with a specified 
%   number of fully connected modules linked together by evenly distributed
%   remaining random connections.
%   Inputs:     N,      number of vertices (must be power of 2)
%               K,      number of edges
%               sz_cl,  size of clusters (power of 2)

%MAKEFRACTALCIJ     Synthetic hierarchical modular network
%   [CIJ,K] = makefractalCIJ(mx_lvl,E,sz_cl);
%   This function generates a directed network with a hierarchical modular
%   organization. All modules are fully connected and connection density 
%   decays as 1/(E^n), with n = index of hierarchical level.
%   Inputs:     mx_lvl,     number of hierarchical levels, N = 2^mx_lvl
%               E,          connection density fall-off per level
%               sz_cl,      size of clusters (power of 2)

%MAKELATTICECIJ     Synthetic lattice network
%   CIJ = makelatticeCIJ(N,K);
%   This function generates a directed lattice network without toroidal 
%   boundary counditions (i.e. no ring-like "wrapping around").
%   Inputs:     N,      number of vertices
%               K,      number of edges

%MAKERANDCIJ_DIR        Synthetic directed random network
%   CIJ = makerandCIJ_dir(N,K);
%   This function generates a directed random network

%MAKERANDCIJDEGREESFIXED        Synthetic directed random network
%   CIJ = makerandCIJdegreesfixed(N,K);
%   This function generates a directed random network with a specified 
%   in-degree and out-degree sequence. The function returns a flag, 
%   denoting whether the algorithm succeeded or failed.
%   Inputs:     in,     indegree vector
%               out,    outdegree vector

%MAKERINGLATTICECIJ     Synthetic lattice network
%   CIJ = makeringlatticeCIJ(N,K);
%   This function generates a directed lattice network with toroidal 
%   boundary counditions (i.e. with ring-like "wrapping around").
%   Inputs:     N,      number of vertices
%               K,      number of edges

%MAKETOEPLITZCIJ    A synthetic directed network with Gaussian drop-off of
%                   connectivity with distance
%   CIJ = maketoeprandCIJ(N,K,s)
%   This function generates a directed network with a Gaussian drop-off in
%   edge density with increasing distance from the main diagonal. There are
%   toroidal boundary counditions (i.e. no ring-like "wrapping around").
%   Inputs:     N,      number of vertices
%               K,      number of edges
%               s,      standard deviation of toeplitz