%M = [0 2 3 0;0 0 0 3;0 1 0 3;0 0 4 0];
%[VM,Graus,GrauMedio,MClustering,MCoreN,PR] = todasMedidasDigrafos(M)

%..Sa�das
% VM = [N TotalArestas diametro];   %..Num. n�s, arestas e diametro
% Graus = [Kin Kout Ktot];          %..local grau
% GrauMedio = [Gin Gout Gtot];      %..local grau m�dio
% MClustering = CD;                 %..matriz de clustering
% MCoreN = [cnIn rtIn cnOut rtOut]; %..
% PR = [vPageRank MPageRank];
% MCD = [lambda radius efficiency CPL];

function [VM,Graus,GrauMedio,MClustering,MCoreN,PR,MCD] = todasMedidasDigrafos(M)

%..Medidas para redes direcionadas e com pessos

A = double(M>0); %..Matriz de adjacencia bin�ria (digrafo sem pesos )

%..............medidas ......................................
% 1. N�mero total de n�s N
N = length(M);

% 2. N�mero total de arestas  k 
[TotalArestas,Kout] = gradok(A);

%.3. Graus (entrad, saida, total)
 Kout = sum(M,2);    %..grau de sa�da
  Kin = sum(M',2);   %..grau de entrada
 Ktot = Kout + Kin;  %..grau total (in + out) 
 
% 3. Grau m�dio de um n�
Gout = Kout/N;
 Gin = Kin/N;
Gtot = Ktot/N;

% 4. Di�metro da red
       D = inf2zero(floydwarshall(M,N)); %..matriz de distancias
diametro = max(max(D)); %..m�ximo caminho m�nimo

% Mean of finite entries of D(G) - dist�ncia m�dia
lambda = sum(sum(D(D~=Inf)))/length(nonzeros(D~=Inf));
% Eccentricity for each vertex (note: ignore 'Inf') 
ecc = max(D.*(D~=Inf),[],2);
% Radius of graph
radius = min(ecc);  % valor m�nimo da eccentricidade
% Diameter of graph
diameter = max(ecc); 
% Efficiency: mean of inverse entries of D(G)
n = size(D,1);
D = 1./D;                           %invert distance
D(1:n+1:end) = 0;                   %set diagonal to 0
efficiency = sum(D(:))/(n*(n-1));   %compute global efficiency
%..........................................................................



%The average shortest path length is the  characteristic path length of the network.
CPL = mean(D(:));

% 5. Coeficiente de aglomera��o (clustering) C
 CD = fCoeficienteClusteringRedeDirecionada(full(M));

%[Cp,E,Kp,Pp] = coeficienteclustering(M);  C = mean(Cp);

%............................................................

%..bc: betweenness centrality for all vertices in A 
%..E: sparse matrix with the centrality for each edge  
[bc,E] = betweenness_centrality(sparse(M));

%..The core number
%..The core number is the largest integer c such 
% that vertex v exists in a graph where all vertices have degree >= c.
% The vector rt returns the removal time for each vertex.  That
% is, vertex vi was removed at step rt[vi].
  [cnIn rtIn] = core_numbers(sparse(M)); %..in-degree core_numbers
[cnOut rtOut] = core_numbers(sparse(M)'); %..out-degree core_numbers

%..dominator tree for a graph
dTree = lengauer_tarjan_dominator_tree(sparse(M),1);

%..topological order for a dag
toDag = topological_order(sparse(M));

%..Google PageRank
[vPageRank,MPageRank] = fPageRank(M);

%...Vetor de sa�da
VM = [N TotalArestas diametro];
Graus = [Kin Kout Ktot];     %..local
GrauMedio = [Gin Gout Gtot]; %..local
MClustering = CD;
MCoreN = [cnIn rtIn cnOut rtOut];
PR = [vPageRank MPageRank];

MCD = [lambda radius efficiency CPL];


