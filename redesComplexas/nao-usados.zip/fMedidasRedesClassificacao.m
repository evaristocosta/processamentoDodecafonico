%..medidas de redes usadas em classifica��o de g�neros

function VetorMedidas = fMedidasRedesClassificacao(M)

%..Medidas para redes direcionadas e com pessos
A = double(M>0); %..Matriz de adjacencia bin�ria (digrafo sem pesos )
n = length(M); %..n�mero de n�s
%.........................................................................
%........................Matriz de dist�ncia...............................
 [D] = floydwarshall(M,n); %..matriz de distancias [DW,DB,DWB]
 %D = OTHERfloydwarshall(1./M);
%..........................................................................
 
%.................Medidas relacionadas com a dist�ncia.....................
%..Indice de wiener: somat�ria de todos os caminhos m�nimos
IW = sum(sum(D(D~=Inf))); %..em m�dia � mais r�pido do que sum(sum(D));
%..........................................................................
%..Comprimento do caminho caracter�stico...................................
lambda = IW/length(nonzeros(D~=0 & D~=Inf)); %incluindo autoconex�es:
efc2 = length(nonzeros(D~=Inf)); %..diverg�ncia � subtituida por eficiencia, que pela sua vez, � subtituida por ma
%..........................................................................
%..Excentricidade..........................................................
exc = max(D.*(D~=Inf),[],2);
%..........................................................................
%..R�dio...................................................................
raio = min(exc(exc~=0));  % valor m�nimo da eccentricidade
%..........................................................................
%..Di�metro................................................................
diametro = max(exc); 
%..............................................................
%..Efici�ncia global.......................................................
            Dinv = 1./D;                           %..inverso das dist�ncia
 Dinv(1:n+1:end) = 0;                    %..diagonal a zeros porque 1/0=inf
      eficiencia = sum(Dinv(:))/(n*(n-1));  %..calcular a m�dia sem diagonal ppal. com diagonal seria N^2
%..........................................................................
%..M�dia harm�nica.........................................................
ma = 1/eficiencia;
%..........................................................................

%..medidas relacionadas com ciclos.........................................
%                    CC = mean(clustering_coefficients(sparse(M)));
% [CoefCiclico,Ciclosi] = fCoeficienteCiclico(M);
%           [er1,er2,r] = freciprocidade(M);

%...Medidas relacionadas com o grau........................................ 
%....Grau de entrada, sa�da e total........................................
  Kin = sum(A,1);    %..grau de entrada
 Kout = sum(A,2)';    %..grau de sa�da
 Ktot = Kin + Kout;  %..grau total
 MKin = sum(Kin)/n;        %..Grau m�dio de entrada = m�dia Grau de sa�da
MKout = sum(Kout)/n;       %..Grau m�dio de sa�da   = m�dia Grau de entrada
MKtot = sum(Ktot)/n ;      %..Grau m�dio total = n�o tem sentido
 %.....For�a do grau.......................................................
 Sin = sum(M,1);           %..for�a de sa�da
Sout = sum(M,2)';          %..for�a de entrada
Stot = Sin + Sout;         %..for�a total (in + out) 
MSout = sum(Sout)/n;       %..for�a m�dia de sa�da 
 MSin = sum(Sin)/n;        %..for�a m�dio de entrada
MStot = sum(Stot)/n;       %..for�a m�dia total 
%...Pearson
%r0 = assortativity_wei(M,0);
r0 = assortativity(M,0);
% r1 = assortativity_wei(M,1);
% r2 = assortativity_wei(M,2);
% r3 = assortativity_wei(M,3);
% r4 = assortativity_wei(M,4);
%.............................
%....Lei de potencia
% [X1,Y1,P] = Nfrecuencias(eliminarceros(Kin));
% [g1,f1,b1] = fit(X1',Y1','power1'); %..modelo lei de pot�ncia coef= g.a, potencia= g.b

%...M�dia dos graus dos vizinhos...........................................
%[MediaKnn] = fMediaGraudDosVizinhos(A,eliminarceros(Kin));
%X2 = 1:length(MediaKnn);
%Y2 = MediaKnn';
%[g2,f2,b2] = fit(X2',Y2','power1'); %..modelo lei de pot�ncia coef= g.a, potencia= g.b
%..........................................................................
%..Club de ricos ponderados................................................
% RCwd = rich_club_wd(M);
% RCwd = mean(eliminarceros(fApagarLinhasComNaN(RCwd)));
%..........................................................................
%..........................................................................

%...........................Probabilidade de ciclos........................
% [Pq,tpath,plq,qstop,allpths,util] = findpaths(single(M>0),[1:n],n,1);
% [fcyc,pcyc] = cycprob(Pq); %..BD local
%      Mfcyc3 = mean(fcyc(3:n)); %..m�dia da fra��o de ciclos de tamanho k > 3
%      Mpcyc3 = mean(pcyc(3:n)); %..m�dia da prob. tornar ciclo tamanho k-1 > 3
%       fcyc1 = fcyc(1); %..fra��o de autoconex�es ciclos q=1
%       pcyc2 = pcyc(2); %..prob. reciprocidade q=2
%..........................................................................
%                         1   2     3      4       5        6                                         
VetorMedidasDistancia = [IW lambda raio diametro eficiencia ma]; 
%                         7    8    9     10  11   12     13    14     15    16  17
    %VetorMedidasGraus = [MKout MKin MKtot r0 RCwd fcyc1 Mfcyc3 pcyc2 Mpcyc3 g1.a g1.b];
    VetorMedidasGraus = [MKout MKin MKtot r0];
VetorMedidas = [VetorMedidasDistancia VetorMedidasGraus];

%......Medidas
%  1   2     3      4         5      6    7    8    9     10  11   12     13    14     15    16  17
% IW lambda raio diametro eficiencia ma  MKout MKin MKtot r0 RCwd fcyc1 Mfcyc3 pcyc2 Mpcyc3 g1.b g2.b



