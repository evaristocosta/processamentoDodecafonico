%..Fun��o para criar a matriz de adjacencia de um vetor
%..order = 'stable' ou nada

function [M,Vu]= fcrearmatrizadj2(vet);

%[Vu,V,Vi] = unique_no_sort(vector);
[Vu,V,Vi] = unique(vet,'stable');   %..valores e indices �nicos del vector


       Lv = length(Vu);       %..cantidad de valores �nicos
        M = zeros(Lv,Lv);     %..matriz de adjacencia en ceros
       Li = length(Vi);       %..igual a length(vector)

for i=1:Li-1
    M(vet(i),vet(i+1)) = M(vet(i),vet(i+1)) + 1;
end

