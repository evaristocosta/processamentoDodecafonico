%..Fun��o que devolve os descritores melodicos de uma melodia apartir da
%sua matriz de adjac�ncia
%..Vp: Variedade do pitch
%..Da, Db, Dc: Perfis melodicos, asc. , desc. e constante 
%..Id: Intervalos disonantes
%..EC: Estabilidade do contorno melodico
%..MP: Movimentos por passo
%..

function [Vp,Da,Dd,Di,Id,MP] = descritoresMelodicosRC(Mp)

A = single(Mp>0);

%..........................Graus...........................................
 Kout = sum(Mp,2);   %..grau de sa�da
  Kin = sum(Mp',2);  %..grau de entrada
 Ktot = Kout + Kin;  %..grau total local (in + out) 
   Nt = sum(Kout); %..total de arestas
%..........................................................................

%........................Matriz reflexa de M...............................
    M = triu(Mp+Mp');
%..........................................................................

%.........................Variedade do pitch...............................
Npu =  sum(min(sum(A,1),1)); %..igual a sum(sum(A,1)>1)
 Vp =  (Npu) /(Nt + 1);
%..........................................................................

%....................Melodic profiles Da, Dd, e Dc.........................
Da = sum(sum(triu(Mp,1))) / Nt;
Dd = sum(sum(tril(Mp,-1))) / Nt;
Di = sum(diag(Mp)) / Nt;
%..........................................................................

%........................Intervalos disonantes.............................
 Id1 = sum(diag(M,1));  %..quantidade de inter. de segunda menor
 Id6 = sum(diag(M,6));  %..quantidade de inter. de tritono
Id10 = sum(diag(M,10)); %..quantidade de inter. de setima menor
Id11 = sum(diag(M,11)); %..quantidade de inter. de setima maior
  Id = (Id1+Id6+Id10+Id11)/Nt; 
%..........................................................................

%..movimientos por passo...............
I1s = sum(diag(M,1));
I2s = sum(diag(M,2));
 MP = (I1s+I2s)/Nt;
%......................................


% %..centrado de tonalidade
%  P = [1 5 3 4 5 4 1 2 5 4 5 3 4];
%  R = [2 1 4 5 6 7 1 5 1 9 8 7 1];
% [Mr,nosr] = fcrearmatrizadj(R);
% nq = max([sum(Mr(1,:)),sum(Mr(:,1))]); %..k de sa�da e entrada do n� 1
% 
% [Mpr,Nospr] = fMAdjPR(R,P);
% 
% nqq = (sum(Mpr(3,:))+sum(Mpr(:,3)))/2;  %..achar a linha da tonica e da  dominante
% 
% CT = nqq/nq;
% %.........................................................................



